
from django.contrib import admin
from django.urls import path
from signup import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include 
from django.contrib.auth import views as auth_views 
urlpatterns = [
    path('admin/', admin.site.urls, name='admin_namespace'),
    path('signupForm', views.signup_view, name='signup_form'),
    path('signin/', views.loginpage, name='signin'),  # Changed signin to loginpage
    path('signin/loginForm', views.loginpage, name='loginForm'),
    path('password_reset/',auth_views.PasswordResetView.as_view(),name='password_reset'),
    path('password_reset/done/',auth_views.PasswordResetDoneView.as_view(),name='password_reset_done'),
    path('accounts/login/password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('reset/<uidb64>/<token>/',auth_views.PasswordResetConfirmView.as_view(),name='password_reset_confirm'),
    path('reset/done/',auth_views.PasswordResetCompleteView.as_view(),name='password_reset_complete'),
    path('admin_profile/', views.admin_profile, name='admin_profile'),
    path('delete_user/', views.delete_user, name='delete_user'),
    path('user_profile/', views.user_profile, name='user_profile'),
    path('', views.signup_view, name='signup'),
    path('create_user/', views.create_user, name='create_user'),
    path('home/', views.homepage, name='home'),
    path('logout/', views.logoutpage, name='logout'),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
