from django.contrib import admin
from .models import MyModel  # Import your model

class MyModelAdmin(admin.ModelAdmin):
    pass  # You can customize the admin interface here

admin.site.register(MyModel, MyModelAdmin) 