from multiprocessing import AuthenticationError
from django.http import BadHeaderError, HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User , auth
from django.contrib.auth import authenticate, login , logout
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.views import PasswordChangeView
from django.contrib.auth.views import PasswordResetView
from django.urls import reverse_lazy
from django.contrib.auth.hashers import make_password
from django.core.mail import send_mail
from django.contrib.auth.forms import PasswordResetForm
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode

def signup_view(request):
    if request.method == 'POST':
        uname = request.POST.get('username')
        email = request.POST.get('email')
        Password = request.POST.get('password')

        if uname and email and Password:
            user = User.objects.create_user(uname, email, Password)
            user.save()
            return redirect('signin')
        else:
            return HttpResponse("Error creating user. Please try again.")
    else:
        return render(request, 'signup.html')
    pass

def loginpage(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if user.is_staff:  # Check if user is an admin
                return redirect('admin_profile')
            else:
                return redirect('user_profile')
        else:
            return HttpResponse("Invalid username or password")
    else:
        return render(request, 'signin.html')
    pass

def password_reset_request(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data['email']
            associated_users = User.objects.filter(email=data)
            if associated_users.exists():
                for user in associated_users:
                    subject = "Password Reset Requested"
                    email_template_name = "registration/password_reset_email.txt"
                    c = {
                    "email": user.email,
                    'domain': 'example.com',  # Replace with your domain
                    'site_name': 'Your Site Name',
                    "uid": urlsafe_base64_encode(force_bytes(user.pk)),
                    "user": user,
                    'token': default_token_generator.make_token(user),
                    'protocol': 'http',
                    }
                    email = render_to_string(email_template_name, c)
                    try:
                        send_mail(subject, email, 'your_email@example.com', [user.email], fail_silently=False)
                    except BadHeaderError:
                        return HttpResponse('Invalid header found.')
                    return redirect("/password_reset/done/")
    form = PasswordResetForm()
    return render(request, "registration/password_reset_form.html", {"form": form})

def admin_profile(request):
    if request.user.is_staff:
        users = User.objects.all()
    return render(request, 'admin_profile.html', {'users': users})
pass

def delete_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        user = User.objects.get(username=username)
        user.delete()
        return redirect('admin_profile.html')  # redirect to admin profile page
    return redirect('admin_profile.html')  # redirect to admin profile page if not a POST request
pass

def user_profile(request):
    return render(request, 'user_profile.html')
pass

def create_user(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('admin_profile')
    else:
        form = UserCreationForm()
    return render(request, 'create_user.html', {'form': form})


def homepage(request):
    if request.user.is_authenticated:
        if request.method=="POST":
            fm=homepage(request.POST, instance=request.user)
            if fm.is_valid():   
                fm.save()
            else:
                fm = homepage(instance=request.user)
    return render(request,'home.html')

def logoutpage(request):
    logout(request)
    return redirect('signin')